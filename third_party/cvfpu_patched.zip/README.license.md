# Licensing

FPnew is released under the *SolderPad Hardware License*, which is a permissive license based on Apache 2.0. Please refer to the [SolderPad license file](LICENSE.solderpad) for further information.

The T-Head E906 and C910 DivSqrt units, integrated into FPnew in [`vendor/opene906`](vendor/opene906) and [`vendor/openc910`](vendor/openc910), are reseased under the *Apache License, Version 2.0*. Please refer to the [Apache 2.0 license file](LICENSE.apache) for further information.
